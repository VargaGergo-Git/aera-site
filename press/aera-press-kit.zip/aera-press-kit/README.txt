AERA PRESS KIT (aerahealth.app/press, updated 9 November 2026)

ONE LINE
Replay your run. Understand your body.

ABOUT 50 WORDS
Aera is an iPhone and Apple Watch app that replays your runs in 3D over the real ground, with pace, heart rate and climb, and reads your sleep, heart and training against your own usual, not a population average. Every number opens a short note on how it was worked out.

ABOUT 150 WORDS
Aera is an iPhone and Apple Watch app for people who run with a watch. It replays a run as a short film over the real ground, with pace, heart rate, climb and distance live on screen. Runs recorded on Apple Watch or iPhone carry their GPS route; Garmin, Polar and COROS runs replay once their file is imported.

It reads Apple Health and compares your nights, resting heart rate, heart rate variability, effort and progress with your own usual range, and says so while it is still learning. It estimates a body age beside your calendar age, draws loops on real paths from where you stand, and guides you turn by turn on iPhone and Apple Watch. Every number opens a short article on how it was worked out and where it stops being reliable.

There is no account, and health numbers are worked out and kept on the iPhone. Aera is free, with an optional Premium. It is made by one person, Gergő Varga, in Hungary.

FACT SHEET
Name: Aera: Biological Age & HRV
What it is: An iPhone and Apple Watch app that replays your runs in 3D over the real ground and reads your nights, heart, effort and progress against your own usual range, from Apple Health.
Made by: Gergő Varga, an independent developer in Hungary. One person, no company behind it.
Platforms: iPhone (iOS 26 or later) and Apple Watch, with home screen widgets
Released: First version 21 April 2026. Version 4.0, November 2026.
Price: Free to download and use. Premium is optional, with local prices on the App Store.
Free: Your scores every day with their last 30 days (recovery, stress, strain, sleep); body age; a route planner on real paths with turn-by-turn directions on iPhone and Apple Watch and five saved routes; every workout read and every personal best; the 3D replay of any workout with a GPS route from the last seven days; the last 30 days of every export.
Premium: Your whole history; body age month by month; the 3D replay of older workouts, as a video to share, and of a route before you go; more than five saved routes; the report for yourself and the longer reports for your doctor.
Privacy: No account and no sign-in. Health numbers are worked out and kept on the iPhone. Usage counts stay off until the user turns them on (in the UK and Switzerland, until the user turns them off), and neither they nor crash reports include health values.
Languages: English, Hungarian, German, Spanish and French in full; Italian, Japanese, Portuguese and Traditional Chinese in part.
Field Guide: Every number in the app opens a short article on how it was worked out, the research behind it and where it stops being reliable. Each article lists its sources.
Ratings: 5.0 from 8 ratings on the Hungarian App Store and 5.0 from 1 on the Canadian one. No ratings yet in the US, UK or Germany. (Checked 9 November 2026.)
Category: Health & Fitness. Not a medical device; watch measurements such as sleep stages are estimates.

LINKS
App Store: https://apps.apple.com/app/id6762456252
Website: https://aerahealth.app/
Contact: hello@aerahealth.app

Screenshots were captured from version 4.0 on 7 November 2026 and show a demo profile, not a real person's health data.
