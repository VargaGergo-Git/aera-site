AERA PRESS KIT (aerahealth.app/press, updated 9 October 2026)

ONE LINE
Aera turns last night into today's run from your front door.

ABOUT 50 WORDS
Aera is an iPhone and Apple Watch app that reads Apple Health and tells you each morning how hard to go: rest day, go easy, good to go or go for it. Sleep, recovery, stress and strain are read against your own usual, and every number shows how it was worked out.

ABOUT 150 WORDS
Aera is an iPhone and Apple Watch app that turns last night into today's run from your front door. It reads Apple Health, compares your sleep, overnight heart rate, heart rate variability and recent training with your own usual range, and each morning gives one plain call: rest day, go easy, good to go or go for it.

From there you can plan a route on real paths from where you stand and follow it turn by turn on your iPhone or Apple Watch. After a run, Flyover replays it in 3D over the real ground. Every number opens a short article on how it was worked out and where it stops being reliable.

There is no account, and health numbers are worked out and kept on the iPhone. Aera is free, with an optional Premium. It is made by one person, Gergő Varga, in Hungary.

FACT SHEET
Name: Aera: Sleep & Running Tracker
What it is: An iPhone and Apple Watch app that reads Apple Health, compares last night and the past week with your own usual range, and tells you each morning how hard to go today: rest day, go easy, good to go or go for it.
Made by: Gergő Varga, an independent developer in Hungary. One person, no company behind it.
Platforms: iPhone (iOS 26 or later) and Apple Watch, with home screen widgets
Released: First version 21 April 2026. Current version 3.2, 29 September 2026.
Price: Free to download and use. Premium is optional: $9.99 a month, $29.99 a year until 31 October 2026 and $39.99 a year after (7-day free trial), or $99.99 once. Local prices on the App Store.
Free: Recovery, stress, strain and a sleep score; the hard, easy or rest call every morning; a route planner on real paths with turn-by-turn directions on iPhone and Apple Watch; every workout read and every personal best; Flyover replays of runs from the last seven days; twelve months of history; data export as JSON or GPX.
Premium: Today's session (how long and how hard), sleep reserve, places, Flyover for older runs, every drawn route kept, history past twelve months, reports and every export format.
Privacy: No account and no sign-in. Health numbers are worked out and kept on the iPhone. Product analytics stay off until the user turns them on and never include health values.
Languages: English, Hungarian, German, Spanish and French in full; Italian, Japanese, Portuguese and Traditional Chinese in part.
Field Guide: Every number in the app opens a short article on how it was worked out, the research behind it and where it stops being reliable. 18 articles, with sources.
Ratings: 5.0 from 7 ratings on the Hungarian App Store and 5.0 from 1 on the German one. No ratings yet in the US or UK. (Checked 9 October 2026.)
Category: Health & Fitness. Not a medical device; watch measurements such as sleep stages are estimates.

LINKS
App Store: https://apps.apple.com/app/id6762456252
Website: https://aerahealth.app/
Contact: hello@aerahealth.app

Screenshots were captured from the current build on 9 October 2026 and show a demo profile, not a real person's health data.
